from time import sleep
sleep(1)
raise ZeroDivisionError